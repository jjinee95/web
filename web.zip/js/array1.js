// array1.js

let ary = [10, 20];
ary.push(30);
ary.push(40);

ary.pop(); // 마지막위치 제거.
ary.shift(); // 첫번위치 제거.
ary.unshift(5); // 첫번위치 추가.

console.log(ary);

let names = [];
while (true) {
    let value = prompt("이름을 입력: ");
    if (value == "stop") {
        break;
    }
    names.push(value);
}
// for.
for (let i = 0; i < names.length; i++) {
    console.log(names[i]);
}
for (let name of names) {
    console.log(name);
}