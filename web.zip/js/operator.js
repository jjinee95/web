// operator.js
// +, -, *, /, %

// let num1 = 10; let num2 = 10;
let num1 = num2 = 10;

let result = num1 + num2;
console.log("결과값 " + (num1 + num2));
console.log("결과값 " + (num1 - num2)); // 결과값10 - 10 => Not a Number.
console.log("10" - num1); // 0
console.log(num1 / num2);
console.log(num1 % 4); // 나눈 몫와 나머지

num1 = parseInt(Math.random() * 30); // 0 ~ 30 사이의 임의 난수. 0.34567456436, 0.12212
console.log(num1);
// num2 => 1 ~ 50 까지의 임의 수를 생성해서 할당.
num2 = parseInt(Math.random() * 50) + 1; // 1 ~ 50
// result = num1 + num2 : 합이 60 이상 "60보다 큰수입니다."
if (num1 + num2 >= 60) {
    console.log("60보다 큰수입니다.")
}

// 누적연산.
let sum = 0;
sum = sum + num1; // 
sum = sum + num1; // 
sum = sum + num1; // 
sum += num1;

sum = sum - num1;
sum -= num1;

sum *= num1; // sum = sum * num1;
sum /= num1; // sum = sum / num1;
sum %= num1; // sum = sum % num1;

sum = "";
sum += "<span>Hello</span>"; // "" + "Hello"
sum += "<span> World</span>"; // "" + "Hello" + " World"

console.log(sum);
document.write(sum);

let fruits = [{fname:"Apple", price: 1000},
              {fname:"Banana", price: 1500},
              {fname:"Cherry", price: 2000},
              {fname:"Melon", price: 1700},
              {fname:"Tomato", price: 1200},
              {fname:"Mango", price: 1900},
              {fname:"BlueBerry", price:2200}]

sum = "<table border=1><tbody>";
for (let i=0; i<7; i++) {
    if (fruits[i].price >= 1500) {
        sum += "<tr><td>" + fruits[i].fname + "</td><td>" + fruits[i].price + "</td></tr>";
    }
}
sum += "</tbody></table>";
document.write(sum);