// forloop.js

// 초기값, 조건식, 증감치 (i = i + 1)
for (let i = 10; i >= 0;) { // i=>1,
    // console.log(i);
    i -= 2; // i=10, 8, 6, 4, 2, 0         i=3, 5, 7, 9
}

// for : 1~10   
// for (let i = 2; i <= 10; i += 2) {
//     console.log(i);
// }

// for (let i = 1; i <= 10; i++) {
//     if (i % 2 == 1) {
//         console.log(i); // 2,4,6,8,10
//     }
// }

let sum = 0;
for (let i = 1; i <= 10; i++) {
    if (i % 2 == 1) {
        sum += i;
    }
}
console.log(sum); // 짝수합: 30, 홀수합: 25
document.write('<table border=1>');
// for (let k = 2; k <= 5; k++) {
    let dan = 5;
    for (let num = 1; num <= 9; num++) {
        document.write('<tr>');
        console.log(dan + " * " + num + " = " + (dan * num));
        document.write('<td> ' + dan + ' </td><td> * </td><td> ' + num + ' </td><td> = </td><td> ' + (dan * num) + ' </td>');
        document.write('</tr>');
    }
// }
document.write('</table>');
console.log('end of for');


let fruits = [{fname:"Apple", price: 1000},    // index: 0
              {fname:"Banana", price: 1500},   // index: 1
              {fname:"Cherry", price: 2000},   // index: 2
              {fname:"Melon", price: 1700},    // index: 3
              {fname:"Tomato", price: 1200},   // index: 4
              {fname:"Mango", price: 1900},    // index: 5
              {fname:"BlueBerry", price:2200}] // index: 6

document.write('<table>');
document.write('<thead><tr><th>과일</th><th>가격</th></tr></thead>');
// tbody 작성. fruits[0].fname, fruits[0].price
sum = 0;
document.write('<tbody>');
for (let i = 0; i < 7; i++) {
    document.write('<tr><td>' + fruits[i].fname + '</td><td>' + fruits[i].price + '</td></tr>');
    sum += fruits[i].price;
}
document.write('<tr><td>합계</td><td>' + sum + '</td></tr>');

document.write('</tbody>');
document.write('</table>');

// 확장 for.
for (let fruit of fruits) {
    // fruit => {fname:'Apple', price: 1000}
    console.log('과일: ' + fruit.fname +", 가격: " + fruit.price);
}
