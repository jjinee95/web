// string2.js
// trim(), trimStart(), trimEnd() : 공백제거.
let str = "    Hello, World    ";
let result = str.trimEnd();

// 대문자, 소문자 : toUpperCase, toLowerCase
result = str.toUpperCase() // 반환값이 문자열.
    .toLowerCase() // 
    .trim(); //

result = str.trim().substring(0, 5).toUpperCase() +
    str.trim().substring(5);
//

// 문자열을 대체(replace)
//"    Hello, World    ";
result = str.replace("World", "world");
console.log(result); // "    Hello, world    "

str = ["김기훈", "김근연", "이소라", "오수현", "박김희"]

function findKim() {
    for (let word of str) {
        if (word.startsWith("김")) { // String.endsWith("희")
            console.log(word);
        }
    }
}
findKim();

// substring => slice(시작인덱스, 종료인덱스)
str = "Hello, World"; // 12
result = str.slice(-5);

// 주민번호(960305-1234567)
function checkGender(jumin) {
    if (jumin.charAt(7) == "1" || jumin.charAt(7) == "3") {
        return "남자";
    } else if (jumin.charAt(7) == "2" || jumin.charAt(7) == "4") {
        return "여자";
    } else {
        return "잘못된 번호입니다.";
    }
}

result = checkGender("960305-1234567");
console.log(result);
result = checkGender("960305-2244567");
console.log(result);
result = checkGender("030305-3234567");
console.log(result);
result = checkGender("030308-4234567");
console.log(result);