import { ourClass } from "./variable1.js";

console.log(ourClass)