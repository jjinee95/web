// whileloop.js

let i = 0;
while (i < 10) {

    console.log(i);
    i++;
}

let isOK = true;
while (isOK) {
    let randomVal = parseInt(Math.random() * 10);
    console.log(randomVal);
    if (randomVal % 3 == 0) {
        break; // 반복문을 종료.
    }
}

let sum = 0;
while (isOK) {
    sum += parseInt(Math.random() * 10);
    console.log(sum);
    if (sum > 100) { // 누적값이 100 값을 넘어서면...
        break;
    }
}
console.clear();

// while (true) {
//     let msg = prompt("문자입력하세요: ");
//     console.log(msg);
//     if (msg == "stop") {
//         break;
//     }
// }

// Math.random => 0 ~ 100까지의 임의 수 생성. => randomval;
// prompt("숫자를 입력: ") => inputval;
// 입력한값이 임의의값 큽니다.

console.log('end of while');