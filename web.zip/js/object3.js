// object3.js

// 책: Book (제목:title, 저자:author, 출판사:press, 가격:price);
class Book {

}
// 다산북스, 김영사, 범우사
let b1 = new Book();

let books = []; // 6건 입력.

function findBooks(press) {

}

let result = findBooks("김영사");
console.log(result);