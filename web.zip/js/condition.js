// condition.js

let score = parseInt(Math.random() * 60) + 40; // 40 ~ 100 임의의 정수값.
let pass = "";

if (score >= 60) {
    pass = "합격";
} else {
    pass = "불합격";
}

pass = (score >= 60) ? "합격" : "불합격";
console.log(pass);

if (score >= 90) {
    pass = "A";
} else { // 90보다 작은값.
    if (score >= 80) {
        pass = "B";
    } else { // 80보다 작은값. 
        if (score >= 70) {
            pass = "C";
        } else { // 70보다 작은값.
            pass = "D";
        }
    }
}
// score = 80;
// if조건문이 하나이고 조건을 4개의 조건으로 한번만 실행.
// 95, 85, 75 => A+, B+, C+
if (score >= 90) {
    if (score >= 95) {
        pass = "A+";
    } else {
        pass = "A";
    }
} else if (score >= 80) {
    if (score >= 85) {
        pass = "B+";
    } else {
        pass = "B";
    }
} else if (score >= 70) {
    if (score >= 75) {
        pass = "C+";
    } else {
        pass = "C";
    }
} else {
    pass = "D";
}

if (score >= 95) {
    pass = "A+";
} else if (score >= 90) {
    pass = "A";
} else if (score >= 85) {
    pass = "B+";
} else if (score >= 80) {
    pass = "B";
} else if (score >= 75) {
    pass = "C+";
} else if (score >= 70) {
    pass = "C";
} else {
    pass = "D";
}

console.log(pass);