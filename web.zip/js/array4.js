// array4.js

let names = ["김도협", '채동윤', '민성인'];
names.push('권근희');
names.splice(names.length, 0, '김동견');
names.splice(names.length, 0, '이재현');
names.splice(names.length, 0, '이정용');
names.splice(0, 0, '김기훈');
names.splice(0, 0, '이소라');
names.splice(0, 0, '오수현');

console.log(names);

// 1) prompt("이름입력: ") 2) 이름1,이름2,이름3.... stop입력.
let delNames = [];
while (true) {
    let inval = prompt('이름입력: ')
    if (inval == 'stop') {
        break;
    }
    delNames.push(inval);
}

if (delNames.length) {
    removeName(delNames);
}

function removeName(name) {
    for (let nm of name) {
        let idx = names.indexOf(nm); // 입력받은 이름의 위치값.
        names.splice(idx, 1);
    }
    console.log(names);
}