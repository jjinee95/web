// objectEx3.js
let students = [];
const std1 = {
    std_no: '1-001', // stdNo
    std_name: "홍길동",
    std_math: 80,
    std_eng: 85
}
const std2 = {
    std_no: '1-002', // stdNo
    std_name: "김현식",
    std_math: 70,
    std_eng: 75
}
const std3 = {
    std_no: '1-003', // stdNo
    std_name: "김익수",
    std_math: 90,
    std_eng: 70
}
students.push(std1);
students.push(std2);
students.push(std3);
students.push({
    std_no: '1-004',
    std_name: "손수희",
    std_math: 88,
    std_eng: 95
})

function getStudents(totalScore) {
    // 새로운 배열을 선언.
    let overMath = [];
    for (let std of students) {
        if (std.std_math + std.std_eng >= totalScore) {
            overMath.push(std);
        }
    }
    return overMath;
}

let result = getStudents(150);
console.log(result);

// 점수의 영어점수 제일 큰 사람만 반환.
function getMaxStudent() {
    let temp = 0; // 85, 75, 70
    let student = {};

    for (let i = 0; i < students.length; i++) {
        if (temp < students[i].std_eng) {
            temp = students[i].std_eng;
            student = students[i];
        }
    }

    return student;
}

result = getMaxStudent();
console.log(result);