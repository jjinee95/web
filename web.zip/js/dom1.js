// dom1.js

console.log('dom 실행.');

let show = document.querySelector('#show'); // <div id='show'></div>

let pTag = document.createElement('p'); // <p>Hello</p>
pTag.innerText = 'Hello';

show.appendChild(pTag); // show > pTag

let btn = document.createElement('button'); // <button id='btn'>클릭</button>
let txt = document.createTextNode('클릭'); //  
// btn.innerText = "클릭";
btn.appendChild(txt);
btn.onclick = function() {
    console.log('클릭되었습니다.');
}
btn.setAttribute('id', 'btn'); // 속성지정.
show.appendChild(btn);

let fruits = ['apple','banana','cherry'];
let ul = document.createElement('ul'); // <ul><li></li><li></li></ul>
for(let fruit of fruits) {
    let li = document.createElement('li');
    li.innerText = fruit;
    ul.appendChild(li);
}
show.appendChild(ul);

let sendp = document.querySelector('#show>p:nth-of-type(2)');
sendp.remove();
console.log(sendp);


// querySelector(선택자)
// createElement(요소)
// 부모.appendChid(자식)
// remove()

// <ol>내가좋아하는과일<li>복숭아</li><li>사과</li><li>포도</li></ul>




