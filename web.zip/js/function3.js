// function3.js

let obj = {
    name: "홍길동",
    age: 20,
    score: 88
}

function sum(num1 = 0, num2 = 0) {
    return num1 + num2;
}
console.log(sum(10));

function printObj(args = {name:"init", age:0}) {
    for (let arg in args) {
        console.log(arg, args[arg]);
    }
}
printObj(obj);

let numAry = [10,20,30]
function printAry(ary = []) {
    for(let num of ary) {
        console.log(num);
    }
}
printAry(numAry);

function sum(a, b) {
    return a+b;
}
function minus(a,b) {
    return a-b;
}
function printFunc(fnc) {
    let result = fnc(10,5);
    console.log(result);
}
printFunc(minus);